using System.Collections.Generic;

public interface IDashboardView
{
    string ChartTitle { get; set; }
    void DisplayChartData(Dictionary<string, int> data);
    void ShowEmailList(List<string> emails);
    void DisplayServiceNowItems(List<string> items);
    // Property to set the data source for the DataGridView
    object EmailGridDataSource { set; }

    // Show column selection dialog
    void ShowColumnSelectionDialog(List<string> availableColumns, List<string> selectedColumns);
// New method to set visible columns
    void SetVisibleColumns(List<string> selectedColumns);
}
