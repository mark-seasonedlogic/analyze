using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using NLog;
using BBIReporting;

public class DashboardPresenter
{
    private readonly Logger _log;
    private readonly IDashboardView _view;
    private readonly BindingList<AndroidDevice> _deviceList;  // Sample data
    private List<string> _selectedColumns;
    private List<AlertRuleBase> _alertRules;  // List of configurable alert rules
    private readonly Dictionary<string, DeviceAlertRuleInfo> _deviceAlertRuleInfoMap = new Dictionary<string, DeviceAlertRuleInfo>();
 
        private List<AndroidDevice> GetOnlineDevices(string restaurantNumber)
        {
            AndroidDeviceFilter filter = new AndroidDeviceFilter
            {
                Restaurant = restaurantNumber,
                IsOnline = true
            };

            List<AndroidDevice> filteredDevices = AndroidDeviceFilterHelper.FilterDevices(_deviceList.ToList<AndroidDevice>(), filter);
#if DEBUG
            foreach (var device in filteredDevices)
            {
                _log.Info($"Device Name: {device.Name}, Online: {device.IsOnline}");
            }
#endif

            return filteredDevices;
        }
        private List<AndroidDevice> GetOfflineDevices(string restaurantNumber)
        {
            AndroidDeviceFilter filter = new AndroidDeviceFilter
            {
                Restaurant = restaurantNumber,
                IsOnline = false
            };

            List<AndroidDevice> filteredDevices = AndroidDeviceFilterHelper.FilterDevices(_deviceList.ToList<AndroidDevice>(), filter);
#if DEBUG
            foreach (var device in filteredDevices)
            {
                _log.Info($"Device Name: {device.Name}, Online: {device.IsOnline}");
            }
#endif

            return filteredDevices;
        }

    public DashboardPresenter(IDashboardView view, Logger logger)
    {
        _log = logger;
        _view = view;
        _deviceList = DataHelper.LoadAndroidDevicesFromCsv("C:\\Users\\MarkYoung\\SourceCode\\POSi Tablet Monitoring Dashboard - Release\\TestAndroidData.csv");
        // Initialize sample data
        /*
         _deviceList = new BindingList<AndroidDevice>
            {
                new AndroidDevice { Name = "Device1", LastSeen = DateTime.Now, IpAddress = "192.168.1.1", IsOnline = true },
                new AndroidDevice { Name = "Device2", LastSeen = DateTime.Now.AddDays(-1), IpAddress = "192.168.1.2", IsOnline = false }
            };
        */
        //Set colors
        //LoadKnownColors();
        // Set initial selected columns
        _selectedColumns = DataHelper.GetAvailableColumns();  // All columns by default
        LoadAlertRules();
        // Bind data to the view
        BindDataToView();
    }

    // Load alert rules from the configuration file
    private void LoadAlertRules()
    {
        Debug.Print("Loading alert rules from configuration...");
        _alertRules = RuleConfigurationManager.LoadRules();
        Debug.Print("Loaded {0} alert rules.", _alertRules.Count);
    }


    // Save alert rules to the configuration file
    public void SaveAlertRules()
    {
        var ruleConfigs = ConvertRulesToConfigs(_alertRules);
        RuleConfigurationManager.SaveRules(ruleConfigs);
    }

    // Convert the device list to a DataTable and update the view
    private void BindDataToView()
    {
        foreach (var device in _deviceList)
        {
            // Calculate and store the status color for each device
            GetStatusColor(device);
        }
        // Update the view's data source
        _view.EmailGridDataSource = _deviceList;

        // Configure the columns in the view based on selected columns
        UpdateGridColumns();
    }

    // Configure the columns based on selected columns
    private void UpdateGridColumns()
    {
        // Set mandatory column that should always be displayed (e.g., "Name")
        const string mandatoryColumn = "StatusColumn";
        var columnsToDisplay = new List<string>(_selectedColumns) { mandatoryColumn };

        // Tell the view to update the columns
        _view.SetVisibleColumns(columnsToDisplay);
    }

    // Show column selection dialog and update the grid if columns change
    public void ConfigureColumns()
    {
        // Show column selection dialog in the view
        _view.ShowColumnSelectionDialog(DataHelper.GetAvailableColumns(), _selectedColumns);
    }

    public void UpdateSelectedColumns(List<string> selectedColumns)
    {
        _selectedColumns = selectedColumns;
        _view.SetVisibleColumns(_selectedColumns);  // Call view method to apply column visibility
        BindDataToView();  // Rebind the data to the view
    }

    public void LoadChartData()
    {
        // Simulate loading data for the chart
        var data = new Dictionary<string, int>
        {
            { "Category 1", 10 },
            { "Category 2", 20 },
            { "Category 3", 30 }
        };

        _view.DisplayChartData(data);
    }

    public void LoadEmailList()
    {
        // Example email list for testing purposes
        var emailList = new List<string>
        {
            "jason@bloominbrands.com",
            "william@bloominbrands.com",
            "james@bloominbrands.com"
        };
Debug.Print("Removing ShowEmailList method!");
//        _view.ShowEmailList(emailList);
    }

    // Load predefined or test data into the device list
    public void LoadTestData(List<AndroidDevice> testData)
    {
        // Clear existing items and add the new ones
        _deviceList.Clear();
        foreach (var device in testData)
        {
            _deviceList.Add(device);  // Add test data dynamically
        }
        BindDataToView();
    }

    public void LoadServiceNowItems()
    {
        var items = new List<string>
        {
            "INC4686404: Term 1 CLP not printing - Open",
            "INC4679386: NC Missing Labor Hours - In Progress"
        };
        _view.DisplayServiceNowItems(items);
    }
    public Color GetStatusColor(AndroidDevice device)
    {
        // If AirwatchID is not available, skip
        if (string.IsNullOrEmpty(device.AirWatchID.ToString()))
            return Color.Gray;

        // Create or update the FailedRuleInfo object for the current device
        if (!_deviceAlertRuleInfoMap.TryGetValue(device.AirWatchID.ToString(), out DeviceAlertRuleInfo alertInfo))
        {
            alertInfo = new DeviceAlertRuleInfo(device.AirWatchID);
            _deviceAlertRuleInfoMap[device.AirWatchID.ToString()] = alertInfo;
        }

        // Clear previous failed descriptions
        alertInfo.DeviceAlertDescriptions.Clear();

        var alertRules = new List<AlertRuleBase>();
        AlertRuleBase mostSevereAlert = null;

        foreach (var rule in _alertRules)
        {
            if (rule.Evaluate(device))
            {
                if (mostSevereAlert == null || rule.Severity > mostSevereAlert.Severity)
                    mostSevereAlert = rule;
                alertRules.Add(rule);
                alertInfo.DeviceAlertDescriptions.Add(rule.Description);  // Accumulate descriptions
            }
        }

        // Determine the color based on rule failures
        Color statusColor = Color.Green;
/*        var criticalRule = alertRules.FirstOrDefault(r => r.Severity >= 2);  // Severity 1 or 2 are critical
        if (criticalRule != null)
        {
            statusColor = criticalRule.AlertColor;  // Return the critical rule's color (e.g., red)
        }
        else if (alertRules.Count >= 3)
        {
            statusColor = Color.Red;  // 3 or more rules failed
        }
        else
        {
            statusColor = AlertRuleConfig.GetColor();  // All rules passed
        }

*/        // Store the final status color in the FailedRuleInfo object
        alertInfo.StatusColor = mostSevereAlert != null ? mostSevereAlert.AlertColor : statusColor;

        return statusColor;
    }



    /* Old GetStatusColor Implementation
        public Color GetStatusColor(AndroidDevice device)
        {
            foreach (var rule in _alertRules)
            {
                if (rule.Condition(device))
                {
                    var alertColor = rule.AlertColor;
                    Debug.Print("Rule condition met {0}", alertColor);
                    return alertColor;  // Return the color of the first rule that matches
                }
                else
                {
                    Debug.Print("Rule condition not met {0}", rule.Condition(device));
                }
            }

            return Color.Gray;  // Default color if no rule matches
        }
    */

    public DeviceAlertRuleInfo GetAlertRuleInfo(int airwatchId)
    {
        if (airwatchId == 0) return null;

        // Retrieve the FailedRuleInfo based on MACAddress
        _deviceAlertRuleInfoMap.TryGetValue(airwatchId.ToString(), out var failedInfo);
        return failedInfo;
    }

    private List<AlertRuleConfig> ConvertRulesToConfigs(List<AlertRuleBase> rules)
    {
        var configs = new List<AlertRuleConfig>();

        foreach (var rule in rules)
        {
            var config = new AlertRuleConfig
            {
                PropertyName = rule.PropertyName,
                AlertColor = rule.AlertColor,
                Description = rule.Description
            };

            // Set the comparison type based on the specific rule type
            if (rule is EqualsRule equalsRule)
            {
                config.ComparisonValue = equalsRule.ComparisonValue;
                config.ComparisonType = "equals";
            }
            else if (rule is GreaterThanRule greaterThanRule)
            {
                config.ComparisonValue = greaterThanRule.ComparisonValue;
                config.ComparisonType = "greaterthan";
            }
            else if (rule is LessThanRule lessThanRule)
            {
                config.ComparisonValue = lessThanRule.ComparisonValue;
                config.ComparisonType = "lessthan";
            }
            else if (rule is DateGreaterThanRule dateGreaterThanRule)
            {
                //config.ComparisonValue = dateGreaterThanRule.ComparisonDate.ToString("yyyy-MM-dd");  // Format the date as a string
                config.ComparisonType = "dategreaterthan";
            }
            else
            {
                throw new InvalidOperationException($"Unsupported rule type: {rule.GetType().Name}");
            }

            configs.Add(config);
        }

        return configs;
    }




    private List<AlertRuleConfig> ConvertRulesToConfigs(List<AlertRule> rules)
    {
        var configs = new List<AlertRuleConfig>();

        foreach (var rule in rules)
        {
            configs.Add(new AlertRuleConfig
            {
                PropertyName = rule.Condition.Method.GetParameters()[0].Name,
                AlertColor = rule.AlertColor,
                Description = rule.Description
            });
        }

        return configs;
    }
    private List<Func<AndroidDevice, bool>> CreateConditions(List<AlertRuleConfig> configs)
    {
        var conditions = new List<Func<AndroidDevice, bool>>();
        foreach (var config in configs)
        {
            conditions.Add(device =>
            {
                var property = typeof(AndroidDevice).GetProperty(config.PropertyName);
                if (property == null) return false;

                var value = property.GetValue(device)?.ToString();
                return string.Equals(value, config.ComparisonValue, StringComparison.OrdinalIgnoreCase);
            });
        }
        return conditions;
    }
    // New method to evaluate multiple rules and set colors
    private Color DetermineDeviceColor(AndroidDevice device, List<Func<AndroidDevice, bool>> conditions)
    {
        int alertCount = 0;

        // Evaluate each condition
        foreach (var condition in conditions)
        {
            if (!condition(device))
            {
                alertCount++;
            }
        }

        // Logic to determine the color based on failed conditions count
        if (alertCount == 0)
            return Color.Green;    // All conditions passed
        else if (alertCount < 3)
            return Color.Yellow;   // Less than 3 conditions failed
        else
            return Color.Red;      // 3 or more conditions failed
    }
    private Func<AndroidDevice, bool> CreateCondition(AlertRuleConfig config)
    {
        Debug.Print("Executing CreateCondition function!");

        return device =>
        {
            Debug.Print("Inside the delegate for CreateCondition!");

            // Get the specified property from the AndroidDevice object
            var property = typeof(AndroidDevice).GetProperty(config.PropertyName);
            if (property == null)
            {
                Debug.Print("Property '{0}' not found on AndroidDevice.", config.PropertyName);
                return false;
            }

            var value = property.GetValue(device);
            if (value == null) return false;

            var comparisonValue = config.ComparisonValue;
            switch (config.ComparisonType.ToLower())
            {
                case "equals":
                    return value.ToString().Equals(comparisonValue, StringComparison.OrdinalIgnoreCase);
                case "greaterthan":
                    if (value is IComparable comparableValue)
                    {
                        return comparableValue.CompareTo(Convert.ChangeType(comparisonValue, value.GetType())) > 0;
                    }
                    return false;
                case "lessthan":
                    if (value is IComparable comparableValueLess)
                    {
                        return comparableValueLess.CompareTo(Convert.ChangeType(comparisonValue, value.GetType())) < 0;
                    }
                    return false;
                case "contains":
                    return value.ToString().IndexOf(comparisonValue, StringComparison.OrdinalIgnoreCase) >= 0;
                case "dategreaterthan":
                    if (DateTime.TryParse(value.ToString(), out var dateValue) && DateTime.TryParse(comparisonValue, out var comparisonDate))
                    {
                        return dateValue > comparisonDate;
                    }
                    return false;
                case "datelessthan":
                    if (DateTime.TryParse(value.ToString(), out var dateValueLess) && DateTime.TryParse(comparisonValue, out var comparisonDateLess))
                    {
                        return dateValueLess < comparisonDateLess;
                    }
                    return false;
                default:
                    Debug.Print("Unsupported ComparisonType '{0}'", config.ComparisonType);
                    return false;
            }
        };
    }

    /* Old CreateCondition implementation
        private Func<AndroidDevice, bool> CreateCondition(AlertRuleConfig config)
        {
            Debug.Print("Executing CreateCondition function!");
            return device =>
            {
                Debug.Print("Inside the delegate!");

                var property = typeof(AndroidDevice).GetProperty(config.PropertyName);
                Debug.Print("Property is {0}", property == null ? "null" : "not null");
                if (property == null) return false;
                Debug.Print("Property Value {0}, checking against comparison value {1}", property.GetValue(device).ToString(), config.ComparisonValue);
                var value = property.GetValue(device)?.ToString();
                return value.ToLower() == config.ComparisonValue.ToLower();
            };
        }
    */
}
