# POSi-Tablet-Monitoring-Dashboard---Release
 Rules-based Dashboard For Windows
