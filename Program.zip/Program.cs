using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using NLog;


namespace DynamicDashboardWinForm
{
    static class Program
    {
        private static readonly Logger log = LogManager.GetCurrentClassLogger();

        
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new DashboardForm(log));
        }
    }
}
