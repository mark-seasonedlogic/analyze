using System.Net.Http;
using System.Threading.Tasks;

namespace BBIReporting
{
public class AirWatchAPIClient : BaseAPIClient
{
    private readonly string _apiKey;

    public AirWatchAPIClient(HttpClient httpClient, string apiKey) : base(httpClient)
    {
        _apiKey = apiKey;
    }

    // Set Authorization header for AirWatch-specific API keys
    protected override void SetAuthorizationHeader(string token)
    {
        _httpClient.DefaultRequestHeaders.Add("aw-tenant-code", _apiKey);
    }

    public async Task<string> SearchDevicesAsync(string modelIdentifier, string deviceType)
    {
        string url = $"https://api.airwatch.com/mdm/devices/search?model_identifier={modelIdentifier}&device_type={deviceType}";
        return await GetAsync(url);
    }

    // Other AirWatch-specific methods...
}
}
