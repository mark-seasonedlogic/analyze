using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Extensions.DependencyInjection;
using NLog;
using System.Net.Http;
using BBIReporting;

namespace DynamicDashboardWinForm
{
    static class Program
    {
        private static readonly Logger log = LogManager.GetCurrentClassLogger();
        // This will hold the application's ServiceProvider instance
        public static ServiceProvider ServiceProvider { get; private set; }

        
        [STAThread]
        static void Main()
        {
          

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

      // Setup the DI container
        var services = new ServiceCollection();
// Register logger (NLog example)
        services.AddSingleton<Logger>(provider => LogManager.GetCurrentClassLogger());

        // Register HttpClient and your API clients
        services.AddSingleton<HttpClient>();
        services.AddSingleton<MerakiAPIClient>(provider =>
            new MerakiAPIClient(provider.GetRequiredService<HttpClient>(), "your-meraki-api-key"));
        services.AddSingleton<AirWatchAPIClient>(provider =>
            new AirWatchAPIClient(provider.GetRequiredService<HttpClient>(), "your-airwatch-api-key"));

        // Register the DashboardPresenter
        services.AddSingleton<DashboardPresenter>();

        // Register the main form (with injected dependencies)
        services.AddSingleton<DashboardForm>();

        // Build the service provider
        var serviceProvider = services.BuildServiceProvider();

        // Resolve and run the main form
        var mainForm = serviceProvider.GetRequiredService<DashboardForm>();


            Application.Run(new DashboardForm(log));
        }
         private static void ConfigureServices(ServiceCollection services)
        {
            // Register HttpClient (for API calls)
            services.AddHttpClient();

            // Register your API clients
            services.AddSingleton<IMerakiService, MerakiService>();
            services.AddSingleton<IAirWatchService, AirWatchService>();

            // Register forms
            services.AddSingleton<DashboardForm>();  // Main form of your application
        }
    }
    
}
