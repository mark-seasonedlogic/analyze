namespace BBIReporting
{
public class AirWatchService : IAirWatchService
{
    private readonly IAirWatchAPIClient _airWatchApiClient;

    public AirWatchService(IAirWatchAPIClient airWatchApiClient)
    {
        _airWatchApiClient = airWatchApiClient;
    }

    public async Task<List<string>> GetAirWatchDevicesByOrgAsync(string orgId)
    {
        // Assuming the AirWatchAPIClient already implements GetAndroidDevicesByOrgAsString
        return await _airWatchApiClient.GetAndroidDevicesByOrgAsString(orgId);
    }
}
}
