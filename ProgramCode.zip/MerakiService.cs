using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BBIReporting
{
public class MerakiService : IMerakiService
{
    private readonly IMerakiAPIClient _merakiApiClient;

    public MerakiService(IMerakiAPIClient merakiApiClient)
    {
        _merakiApiClient = merakiApiClient;
    }

    public async Task<List<string>> GetMerakiAndroidDeviceUrlsAsync(string apiKey, string orgId, double timeSpan)
    {
        // Use the API client to get the URLs from the Meraki API
        return _merakiApiClient.GetAndroidDevicesURLs(apiKey, orgId, timeSpan);
    }

    public async Task<List<string>> ProcessMerakiUrlsAsync(List<string> urls, IProgress<int> progress)
    {
        // Use the API client to process the URLs, potentially adding business logic here
        return await _merakiApiClient.ProcessUrlsAsync(urls, progress);
    }
}

}