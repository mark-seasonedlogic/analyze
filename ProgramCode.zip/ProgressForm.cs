using System;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace DynamicDashboardWinForm
{
public partial class ProgressForm : Form
{
    public ProgressForm()
    {
        InitializeComponent();
    }

    /// <summary>
    /// Updates the progress bar and label asynchronously with the current progress.
    /// </summary>
    /// <param name="progressValue">The current progress value.</param>
    /// <param name="maximumValue">The maximum value of the progress bar.</param>
    public void UpdateProgress(int progressValue, int maximumValue)
    {
        if (InvokeRequired)
        {
            // Invoke the update on the UI thread
            Invoke((Action)(() => UpdateProgress(progressValue, maximumValue)));
        }
        else
        {
            progressBar.Value = progressValue;
            progressBar.Maximum = maximumValue;
            progressLabel.Text = $"Processing... {progressValue} of {maximumValue}";
        }
    }

    /// <summary>
    /// Closes the form when the operation is complete.
    /// </summary>
    public void CompleteProgress()
    {
        if (InvokeRequired)
        {
            Invoke((Action)(() => Close()));
        }
        else
        {
            Close();
        }
    }
}
}
