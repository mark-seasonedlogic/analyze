using System.Net.Http;
using System.Threading.Tasks;

namespace BBIReporting
{
public class MerakiAPIClient : BaseAPIClient
{
    private readonly string _apiKey;

    public MerakiAPIClient(HttpClient httpClient, string apiKey) : base(httpClient)
    {
        _apiKey = apiKey;
    }

    // Override authorization to set the API key
    protected override void SetAuthorizationHeader(string token)
    {
        _httpClient.DefaultRequestHeaders.Add("X-Cisco-Meraki-API-Key", _apiKey);
    }

    public async Task<string> GetDevicesFromNetworkAsync(string networkId)
    {
        string url = $"https://api.meraki.com/api/v1/networks/{networkId}/devices";
        return await GetAsync(url);
    }

    // Other Meraki-specific methods...
}
}
